﻿Imports System.Threading
Module Partie
    'Class MyProducer

    'private Random rand = new Random(1)
    'private BoundedBuffer boundedBuffer
    'private int totalIters

    'public MyProducer(BoundedBuffer boundedBuffer, int iterations)

    '    this.boundedBuffer = boundedBuffer
    '    totalIters = iterations


    'public Thread CreateProducerThread()

    '    return new Thread(new ThreadStart(this.calculate))

    'private void calculate()

    '    int iters = 0;
    '    do

    '        iters += 1;
    '        Thread.Sleep(rand.Next(2000))
    '        boundedBuffer.WriteData(iters * 4)
    ' while (iters < totalIters)



    '    Class MyConsumer
    'private Random rand = new Random(2)
    'private BoundedBuffer boundedBuffer
    'private int totalIters


    'public MyConsumer(BoundedBuffer boundedBuffer, int iterations)

    '    this.boundedBuffer = boundedBuffer
    '    totalIters = iterations


    'public Thread CreateConsumerThread()

    '    return new Thread(new ThreadStart(this.printValues))


    'private void printValues()

    '    int iters = 0
    '    double pi
    '    do

    '        Thread.Sleep(rand.Next(2000))
    '        boundedBuffer.ReadData(out pi)
    '        System.Console.WriteLine("Value {0} is: {1}", iters, pi.ToString())
    '        iters++
    '    while (iters < totalIters)
    '    System.Console.WriteLine("Done")


    '        Sub Main()
    '            BoundedBuffer BoundedBuffer = New BoundedBuffer()

    '            MyProducer prod = New MyProducer(BoundedBuffer, 20)
    '            Thread producerThread = prod.CreateProducerThread()

    '            MyConsumer cons = New MyConsumer(BoundedBuffer, 20)
    '            Thread consumerThread = cons.CreateConsumerThread()

    '            producerThread.Start()
    '            consumerThread.Start()

    '            Console.ReadLine()
    'End Sub

End Module
