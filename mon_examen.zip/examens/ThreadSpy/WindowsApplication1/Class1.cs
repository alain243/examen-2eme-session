using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsApplication1
{
    class Class1
    {
    }
}
