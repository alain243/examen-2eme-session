﻿Module partie

    Sub Main()

    End Sub

End Module
