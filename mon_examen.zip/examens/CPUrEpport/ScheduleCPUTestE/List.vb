﻿Imports System.Collections.Generic
Public Class List
    'private LinkedList<IProcess> list

    ''/// <summary> 
    ''/// Creates a new LinkedList to contain Testproces-ses
    ''/// </summary>
    'Public CircularProcesList()

    '    this.list = new LinkedList<IProcess>()


    '/// <summary>
    '/// Check whether the queue is empty
    '/// </summary>
    'Public Empty As bool

    '    get

    '        return list.Count == 0;

    'Enum


    '/// <summary> 
    '/// Retrieves the next TestProces from the list
    '/// </summary>
    'public IProcess Next

    '    get

    '        LinkedListNode<IProcess> first = this.list.First
    '        if (first != null)
    '            IProcess nextElement = first.Value
    '            this.list.RemoveFirst()
    '            return nextElement
    '        end if
    '        else

    '            return null

    '  end sub

    ''/// <summary> 
    ''/// Adds a TestProces to the list
    ''/// </summary>
    ''/// <param name="t"> The Testproces to be added</param>
    'public sub AddItem(IProcess t)

    '    list.AddLast(t)

    'End Sub
    ''/// <summary> 
    ''/// Deletes a TestProces from the list
    ''/// </summary>
    ''/// <param name="t"> The TestProces to be deleted</param>
    'public sub deleteItem(IProcess t)

    '    List.Remove(t)
    'End Sub
End Class
